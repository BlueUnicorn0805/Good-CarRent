CREATE TABLE IF NOT EXISTS "urban_wheels_user" (
	"id" text PRIMARY KEY NOT NULL,
	"name" text,
	"email" text NOT NULL,
	"image" text
);
