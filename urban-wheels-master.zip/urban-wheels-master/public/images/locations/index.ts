// @ts-nocheck

export {default as cancun} from './cancun.avif';
export {default as  dubai} from './dubai.avif';
export {default as  paris} from './paris.avif';
export {default as  rome} from './rome.avif';