// @ts-nocheck

export {default as hatchback} from "./hatchback.avif";
export {default as minivan} from "./minivan.avif";
export {default as pickupTruck} from "./pickup-truck.avif";
export {default as sedan} from "./sedan.avif";
export {default as sportsCar} from "./sports-car.avif";
export {default as suv} from "./suv.avif";